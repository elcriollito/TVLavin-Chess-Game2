This is a placeholder bundle.
Replace with real GNU Chess DOS files (GNUCHESS.EXE, etc.)
